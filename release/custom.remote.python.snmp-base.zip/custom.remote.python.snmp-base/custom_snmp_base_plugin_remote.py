import logging
from queue import Queue
from threading import Thread


import ruxit.api.selectors
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.data import PluginMeasurement, PluginProperty, MEAttribute
from ruxit.api.exceptions import AuthException, ConfigException, NothingToReportException
from ruxit.api.events import Event, EventMetadata

logger = logging.getLogger(__name__)

class CustomSnmpBasePluginRemote(RemoteBasePlugin):
    def query(self, **kwargs):
        config = kwargs['config']      
        debug_logging = config['debug']
        if debug_logging:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        # Ensure our inputs are valid
        device = _validate_device(config)
        authentication = _validate_authentication(config)
        _log_inputs(logger, device, authentication)

        # Create the group/device entities in Dynatrace
        g1_name = '{0} - {1}'.format(device['type'], device['group'])
        g1 = self.topology_builder.create_group(g1_name, g1_name)
        e1_name = '{0} - {1}'.format(device['type'], device['host'])
        e1 = g1.create_element(e1_name, e1_name)
        
        # Poll for snmp metrics
        metric_queue = Queue()
        thread_list = []
        mib_list = []

        # Host Resource MIB - TODO Disk filtering
        hr_mib = HostResourceMIB(device, authentication)
        mib_list.append(hr_mib)

        # IF MIB - TODO Interface filtering
        if_mib = IFMIB(device, authentication)
        mib_list.append(if_mib)

        for mib in mib_list:
            # Lambda function - so that the thread can write poll_metrics() into the queue
            t = Thread(target=lambda q,mib: q.put(mib.poll_metrics()), args=([metric_queue, mib]))
            t.start()
            thread_list.append(t)
        for t in thread_list:
            t.join()

        # Keep track of the custom metrics consumed
        custom_metrics = 0
        # Send metrics and dimensions through to DT
        while not metric_queue.empty():
            for endpoint,metrics in metric_queue.get().items():
                for metric in metrics:
                    if metric['is_absolute_number']:
                        e1.absolute(key=endpoint, value=metric['value'], dimensions=metric['dimension'])
                    else:
                        e1.relative(key=endpoint, value=metric['value'], dimensions=metric['dimension'])

                    custom_metrics += 1
                    logger.info('Key = {}, Value = {}, Absolute? = {}, Dimension = {}'.format(endpoint, metric['value'], metric['is_absolute_number'], metric['dimension']))

        if custom_metrics == 0:
            raise NothingToReportException('No metrics were returned when polling {}:{}'.format(device['host'], device['port']))
        else:
            e1.report_property('Custom metrics', str(custom_metrics))

# Helper methods
def _validate_device(config):
    hostname = config.get('hostname')
    group = config.get('group')
    device_type = config.get('device_type')

    # Check inputs are valid...
    if not hostname:
        raise ConfigException('Hostname must not be empty')

    if not group:
        raise ConfigException('Group must not be empty')

    if not device_type:
        raise ConfigException('Device Type must not be empty')

    # Default SNMP port
    port = 161
    host = hostname
    # If entered as 127.0.0.1:1234, extract the ip and the port
    split_host = hostname.split(':')
    if len(split_host) > 1:
        host = split_host[0]
        port = split_host[1]

    try:
        port = int(port)
    except ValueError:
        raise ConfigException('Invalid port \'{}\' in hostname input: {}'.format(port, hostname))

    device = {
        'host': host,
        'port': port,
        'type': device_type,
        'group': group
    }

    return device

def _validate_authentication(config):
    snmp_version = config.get('snmp_version')
    snmp_user = config.get('snmp_user')
    auth_protocol = config.get('auth_protocol')
    auth_key = config.get('auth_key')
    priv_protocol = config.get('priv_protocol')
    priv_key = config.get('priv_key')

    # Check inputs are valid...
    if not snmp_version:
        raise ConfigException('SNMP Version must not be empty')

    if not snmp_user:
        raise ConfigException('SNMP User (v3) or Community String (v2) must not be empty')

    # Other values can be None...
    # V2
        # Expected and ignored
    # V3
        # Match SNMP security level
        # No Auth or Priv = noAuthNoPriv
        # Auth no Priv = authNoPriv
        # Auth + Priv = authPriv

    try:
        snmp_version = int(snmp_version)
    except ValueError:
        raise ConfigException('Expected a number for SNMP Version, received \'{}\''.format(snmp_version))

    if snmp_version == 1:
        raise ConfigException('SNMP Version 1 not yet? supported')
    elif not (snmp_version == 2 or snmp_version == 3):
        raise ConfigException('SNMP Version expected to be 2 or 3, received \'{}\''.format(snmp_version))

    # TODO If auth or priv protocols don't match expected inputs...

    authentication = {
        'version': snmp_version,
        'user': snmp_user,
        'auth': {
            'protocol': auth_protocol,
            'key': auth_key
        },
        'priv': {
            'protocol': priv_protocol,
            'key': priv_key
        }
    }

    return authentication
    
def _log_inputs(logger, device, authentication):
    for key,value in device.items():
        logger.info('{} - {}'.format(key,value))
    for key,value in authentication.items():
        logger.info('{} - {}'.format(key,value))
#####
#LOCAL DTSNMP MODULE
####


""" 
General processing and helper functions
"""

"""
Build a metric dictionary from an snmp connection generator
Args:
    Gen - A generator returned from Poller.snmp_connect_bulk
    Processor - a procesing function for each index (default is to just print)
        index - The current iteration through the generator
        varBinds - The variable bindings from snmpget on an object descriptor - name,value
        metrics - The dictionary of metric endpoints to populate
"""
def process_metrics(gen, processor=None):
        if not processor:
            processor = mib_print

        metrics = {}
        index = 0
        for item in gen:
            index += 1
            errorIndication, errorStatus, errorIndex, varBinds = item

            if errorIndication:
                logger.error(errorIndication)
                # Return early or we could be stuck timing out hitting each index
                # TODO handle this more gracefully
                return metrics
            elif errorStatus:
                logger.error('%s at %s' % (errorStatus.prettyPrint(),
                                    errorIndex and varBinds[int(errorIndex) - 1][0] or '?'))
                # Return early or we could be stuck timing out hitting each index
                # TODO handle this more gracefully
                return metrics
            else:
                processor(index=str(index), varBinds=varBinds, metrics=metrics)

        return metrics

"""
Display in the same format as snmpwalk.
Ripped straight from http://snmplabs.com/pysnmp/quick-start.html
"""
def mib_print(index, varBinds, metrics):
    for varBind in varBinds:
        print(' = '.join([x.prettyPrint() for x in varBind]))

"""
Reducer function to manage custom_metric overload.
Takes a metric dictionary and averages the metrics under each endpoint
Dimensions are then ignored and set to None
TODO - take the reducer as an arg to support sum, count, median...
"""
def reduce_average(metric_dict):
	average_metrics = {}
	for endpoint,metrics in metric_dict.items():
		count = len(metrics)
		if count > 0:
			average_dict = {}
			average_dict['dimension'] = None
			total = 0

			for metric in metrics:
				total += metric['value']
				is_absolute = metric['is_absolute_number']

			average_dict['is_absolute_number'] = is_absolute
			average_dict['value'] = total / count
			average_metrics.setdefault(endpoint, []).append(average_dict)

	return average_metrics

from pysnmp.hlapi import *


class Poller():
    """
    snmp.Poller
    This module wraps the pysnmp APIs to connect to a device

    Usage
    poller = Poller(device, authentication)
    gen = poller.snmp_connect_bulk(self.oids)

    You can then iterate through the generator:
    for item in gen:
        errorIndication, errorStatus, errorIndex, varBinds = item
    """
    
    auth_protocols = {
        'md5': usmHMACMD5AuthProtocol,
        'sha': usmHMACSHAAuthProtocol,
        'sha224': usmHMAC128SHA224AuthProtocol,
        'sha256': usmHMAC192SHA256AuthProtocol,
        'sha384': usmHMAC256SHA384AuthProtocol,
        'sha512': usmHMAC384SHA512AuthProtocol,
        'noauth': usmNoAuthProtocol
    }

    priv_protocols = {
        'des': usmDESPrivProtocol,
        '3des': usm3DESEDEPrivProtocol,
        'aes': usmAesCfb128Protocol,
        'aes192': usmAesCfb192Protocol,
        'aes256': usmAesCfb256Protocol,
        'nopriv': usmNoPrivProtocol
    }

    def __init__(self, device, authentication):
        self.authentication = authentication
        self.device = device
        self._build_auth_object()

    def snmp_connect(self, oid):
        """
        Only use for old SNMP agents
        Prefer snmp_connect_bulk in all cases
        Send an snmp get request
        """
        gen = getCmd(
            SnmpEngine(),
            self.auth_object,
            UdpTransportTarget((self.device['host'], self.device['port'])),
            ContextData(),
            ObjectType(ObjectIdentity(oid)))
        return next(gen)

    def snmp_connect_bulk(self, oids):
        """
        Optimised get - supported with SNMPv2C
        Send a single getbulk request
        Supported inputs:
        String - e.g. 1.3.6.1.2.1.31.1.1.1
        Tuple - e.g. (IF-MIB, ifSpeed)
        List of Tuple - e.g. ([(IF-MIB,ifSpeed), (HOST-RESOURCES-MIB,cpu)])

        Recommended to only call with lists of OIDs from the same table
        Otherwise you can end up polling for End of MIB.
        """
        non_repeaters = 0
        max_repetitions = 25

        if (isinstance(oids, str)):
            oid_object = [ObjectType(ObjectIdentity(oids))]
        elif (isinstance(oids, tuple)):
            oid_object = [ObjectType(ObjectIdentity(*oids))]
        elif(isinstance(oids, list)): # List of Tuple
            oid_object = [ObjectType(ObjectIdentity(*oid)) for oid in oids]

        gen = bulkCmd(
            SnmpEngine(),
            self.auth_object,
            UdpTransportTarget((self.device['host'], self.device['port'])),
            ContextData(),
            non_repeaters,
            max_repetitions,             
            *oid_object,
            lexicographicMode=False)

        return gen

    def _build_auth_object(self):
        authentication = self.authentication
        if (authentication['version'] == 3):
            self.auth_object = UsmUserData(
                authentication['user'],
                authentication['auth']['key'],
                authentication['priv']['key'],
                self.auth_protocols.get(authentication['auth']['protocol'], None),
                self.priv_protocols.get(authentication['priv']['protocol'], None))
        elif(authentication['version'] == 2):
            self.auth_object = CommunityData(authentication['user'], mpModel=1)
        elif(authentication['version'] == 1):
            self.auth_object = CommunityData(authentication['user'], mpModel=0)




class HostResourceMIB():
	"""
	Metric processing for Host-Resouce-Mib
	Host infrastructure statistics

	This is supported by most device types 

	Reference
	http://www.net-snmp.org/docs/mibs/host.html

	Usage
	hr_mib = HostResourceMIB(device, authentication)
	host_metrics = hr_mib.poll_metrics()

	Returns a dictionary containing values for:
	cpu, memory, disk

	TODO implement disk splits
	"""

	mib_name = 'HOST-RESOURCES-MIB'

	def __init__(self, device, authentication):
		self.poller = Poller(device, authentication)

	def poll_metrics(self):
		cpu = self._poll_cpu()
		storage = self._poll_storage()

		cpu_utilisation = cpu.get('cpu', [])
		memory = storage.get('memory', [])
		disk = storage.get('disk', [])

		metrics = {
			'cpu_utilisation': cpu_utilisation,
			'memory_utilisation': memory,
			'disk_utilisation': disk
		}
		return metrics

	def _poll_cpu(self):
		cpu_metrics = [
		    'hrProcessorLoad',
		]
		oids = [(self.mib_name, metric) for metric in cpu_metrics]
		gen = self.poller.snmp_connect_bulk(oids)
		cpu_metrics = process_metrics(gen, calculate_cpu_metrics)
		# Average CPU to reduce custom metrics
		return reduce_average(cpu_metrics)

	def _poll_storage(self):
		storage_metrics = [
		    'hrStorageDescr',
		    'hrStorageSize',
		    'hrStorageUsed',
		]
		oids = [(self.mib_name, metric) for metric in storage_metrics]
		gen = self.poller.snmp_connect_bulk(oids)
		return process_metrics(gen, calculate_storage_metrics)

"""
Processing Function to be used with processing.process_metrics
Extracts the CPU utilisation for each index
hrProcessorLoad -> varBinds[0]
"""
def calculate_cpu_metrics(index, varBinds, metrics):
	cpu = {}
	cpu['value'] = float(varBinds[0][1])
	cpu['dimension'] = {'Index': index}
	cpu['is_absolute_number'] = True
	metrics.setdefault('cpu', []).append(cpu)

"""
Processing Function to be used with processing.process_metrics
Extracts the storage itilisation - splitting into memory/disk types
hrStorageDescr -> varBinds[0]
hrStorageSize -> varBinds[1]
hrStorageUsed -> varBinds[2]
"""
def calculate_storage_metrics(index, varBinds, metrics):
	memory_types = ['memory', 'swap space', 'ram']

	name = varBinds[0][1].prettyPrint()
	size = float(varBinds[1][1])
	used = float(varBinds[2][1])
	utilisation = 0
	# Division by 0 exception - e.g. Swap Space 0 used of 0
	if size > 0:
		utilisation = (used / size)*100

	storage = {}
	storage['dimension'] = {'Storage': name}
	storage['value'] = utilisation
	storage['is_absolute_number'] = True

	# Memory metrics as a dimension under memory_utilisation
	if any(x in name.lower() for x in memory_types):
		metrics.setdefault('memory', []).append(storage)
	else:
		metrics.setdefault('disk', []).append(storage)





class IFMIB():
	"""
	Metric processing for IF-MIB
	Interface network statistics 

	This is supported by most device types

	Reference
	http://www.net-snmp.org/docs/mibs/interfaces.html
	http://cric.grenoble.cnrs.fr/Administrateurs/Outils/MIBS/?oid=1.3.6.1.2.1.31.1.1.1

	Usage
	if_mib = IFMIB(device, authentication)
	if_metrics = if_mib.poll_metrics()

	Returns a dictionary containing values for:
	incoming_traffic, outgoing_traffic, incoming_errors,
	outgoing_errors, incoming_discards, outgoing_discards,
	incoming_packets, outgoing_packets
	"""
	
	mib_name = 'IF-MIB'
	mib_metrics = [
	'ifSpeed', # Bandwidth
	'ifHCInOctets', # Incoming Traffic
	'ifHCOutOctets', # Outgoing Traffic,
	'ifInErrors',
	'ifOutErrors',
	'ifInDiscards',
	'ifOutDiscards',
	'ifHCInUcastPkts',
	'ifHCInBroadcastPkts',
	'ifHCInMulticastPkts',
	'ifHCOutUcastPkts',
	'ifHCOutBroadcastPkts',
	'ifHCOutMulticastPkts',
	]

	def __init__(self, device, authentication):
		self.poller = Poller(device, authentication)
		self.oids = [(self.mib_name, metric) for metric in self.mib_metrics]

	def poll_metrics(self):
		gen = self.poller.snmp_connect_bulk(self.oids)
		return process_metrics(gen, calculate_interface_metrics)

"""
Processing Function to be used with processing.process_metrics
Extracts the following for each interface
ifSpeed -> varBinds[0] (ignored)
ifHCInOctets -> varBinds[1]
ifHCOutOctets -> varBinds[2]
ifInErrors -> varBinds[3]
ifOutErrors -> varBinds[4]
ifInDiscards -> varBinds[5]
ifOutDiscards -> varBinds[6]
ifHCInUcastPkts -> varBinds[7]
ifHCInBroadcastPkts -> varBinds[8]
ifHCInMulticastPkts -> varBinds[9]
ifHCOutUcastPkts -> varBinds[10]
ifHCOutBroadcastPkts -> varBinds[11]
ifHCOutMulticastPkts -> varBinds[12]
"""
def calculate_interface_metrics(index, varBinds, metrics):
	#bandwidth = {'value': float(varBinds[0][1])}
	incoming_traffic = {'value': float(varBinds[1][1])}
	outgoing_traffic = {'value': float(varBinds[2][1])}
	incoming_errors = {'value': float(varBinds[3][1])}
	outgoing_errors = {'value': float(varBinds[4][1])}
	incoming_discards = {'value': float(varBinds[5][1])}
	outgoing_discards = {'value': float(varBinds[6][1])}
	# Unicast + Broadcast + Multicast
	total_incoming = float(varBinds[7][1]) + float(varBinds[8][1]) + float(varBinds[9][1])
	total_outgoing = float(varBinds[10][1]) + float(varBinds[11][1]) + float(varBinds[12][1])
	incoming_packets = {'value': total_incoming}
	outgoing_packets = {'value': total_outgoing}

	# All metrics are relative
	# Calculate per interface... so same dimension for each
	dict_list = [incoming_traffic, outgoing_traffic, incoming_errors, outgoing_errors, incoming_discards, outgoing_discards, incoming_packets, outgoing_packets]
	for metric_dict in dict_list:
		metric_dict['is_absolute_number'] = False
		metric_dict['dimension'] = {'Interface': index}

	# Add this interface to our list so far
	metrics.setdefault('incoming_traffic', []).append(incoming_traffic)
	metrics.setdefault('outgoing_traffic', []).append(outgoing_traffic)
	metrics.setdefault('incoming_errors', []).append(incoming_errors)
	metrics.setdefault('outgoing_errors', []).append(outgoing_errors)
	metrics.setdefault('incoming_discards', []).append(incoming_discards)
	metrics.setdefault('outgoing_discards', []).append(outgoing_discards)
	metrics.setdefault('incoming_packets', []).append(incoming_packets)
	metrics.setdefault('outgoing_packets', []).append(outgoing_packets)



